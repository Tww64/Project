for _ in range(3):
    width = float(input("Enter a number: "))
    area = width
    print(area)
