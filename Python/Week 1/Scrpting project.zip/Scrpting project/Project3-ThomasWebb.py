for _ in range(3):
    width = float(input("Enter the base: "))
    height = float(input("Enter the height: "))
    area = width * height
    print("The area is", area)
