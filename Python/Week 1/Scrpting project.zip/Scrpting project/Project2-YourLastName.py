for _ in range(3):
    width = float(input("Enter the width: "))
    height = float(input("Enter the Length: "))
    area = width * height
    print(area)
