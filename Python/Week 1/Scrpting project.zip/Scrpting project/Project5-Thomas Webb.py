for _ in range(3):
    height = float(input("Enter the height: "))
    width = float(input("Enter the width: "))
    depth = float(input("Enter the depth: "))
    area = height * width * depth
    print(area)
