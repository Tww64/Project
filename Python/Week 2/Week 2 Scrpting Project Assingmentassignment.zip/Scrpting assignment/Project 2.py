
edge_length = int(input("Enter the length of an edge of the cube: "))
surface_area = 6 * (edge_length ** 2)
print("The surface area of the cube is:", surface_area)
