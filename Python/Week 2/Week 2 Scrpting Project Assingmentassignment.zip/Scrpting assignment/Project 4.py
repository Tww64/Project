radius = float(input("Enter the radius of the sphere: "))

diameter = 2 * radius
circumference = 2 * 3.14159 * radius
surface_area = 4 * 3.14159 * (radius ** 2)
volume = (4/3) * 3.14159 * (radius ** 3)

print("Diameter:", diameter)
print("Circumference:", circumference)
print("Surface Area:", surface_area)
print("Volume:", volume)
