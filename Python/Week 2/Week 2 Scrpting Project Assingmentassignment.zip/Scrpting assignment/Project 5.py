
mass = float(input("Enter the object's mass in kilograms: "))
velocity = float(input("Enter the object's velocity in meters per second: "))

momentum = mass * velocity

print("The object's momentum is:", momentum, "kg*m/s")
